extends Node2D

# The Python compiler samples all transforms at exact integer frame indices.
# Each PNG is captured only after the corresponding drawing has completed.
var timeline: Dictionary
var textures: Dictionary = {}
var sprites: Array[Sprite2D] = []
var render_target: SubViewport

func fail(message: String) -> void:
	var file = FileAccess.open("res://runtime-status.json", FileAccess.WRITE)
	if file: file.store_string(JSON.stringify({"status":"FAIL", "error":message}))
	push_error(message)
	get_tree().quit(1)

func _ready() -> void:
	var file = FileAccess.open("res://timeline.json", FileAccess.READ)
	if not file:
		fail("Missing timeline")
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if not parsed is Dictionary:
		fail("Invalid timeline")
		return
	timeline = parsed
	# Native windows may be clamped to the desktop work area. Render to an
	# independent GPU canvas whose dimensions are the requested output size.
	render_target = SubViewport.new()
	render_target.size = Vector2i(timeline.project.resolution[0], timeline.project.resolution[1])
	render_target.world_2d = World2D.new()
	render_target.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(render_target)
	for frame in timeline.frames:
		for item in frame.items:
			if not textures.has(item.image):
				var image = Image.load_from_file("res://" + item.image)
				if image == null or image.is_empty():
					fail("Missing image " + item.image)
					return
				textures[item.image] = ImageTexture.create_from_image(image)
	call_deferred("render_frames")

func render_frames() -> void:
	for frame in timeline.frames:
		for sprite in sprites:
			render_target.remove_child(sprite)
			sprite.queue_free()
		sprites.clear()
		var zoom = Vector2(frame.camera_zoom[0], frame.camera_zoom[1])
		var camera = Vector2(frame.camera_position[0], frame.camera_position[1])
		var center = Vector2(timeline.project.resolution[0], timeline.project.resolution[1]) / 2.0
		render_target.canvas_transform = Transform2D(0.0, zoom, 0.0, center - camera * zoom)
		for item in frame.items:
			var sprite = Sprite2D.new()
			sprite.centered = false
			sprite.texture = textures[item.image]
			sprite.position = Vector2(item.position[0], item.position[1])
			sprite.scale = Vector2(item.scale[0], item.scale[1])
			sprite.rotation_degrees = item.rotation
			sprite.z_index = int(item.z)
			render_target.add_child(sprite)
			sprites.append(sprite)
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var image = render_target.get_texture().get_image()
		if image == null or image.is_empty():
			fail("Viewport readback failed")
			return
		if image.get_size() != render_target.size:
			fail("Native render target resolution mismatch")
			return
		var err = image.save_png("res://frames/frame-%06d.png" % int(frame.frame))
		if err != OK:
			fail("PNG save failed: " + str(err))
			return
	var status = FileAccess.open("res://runtime-status.json", FileAccess.WRITE)
	status.store_string(JSON.stringify({"status":"PASS", "frame_count":timeline.frames.size()}))
	status.close()
	get_tree().quit(0)
