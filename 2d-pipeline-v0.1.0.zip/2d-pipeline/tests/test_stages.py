import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import contract
import fixture
import pipeline


class StageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = fixture.generate(self.root)
        self.c = json.loads(self.path.read_text())
        for stage in contract.STAGES:
            self.c['stages'][stage] = {'command': [sys.executable, '-c',
                f"from pathlib import Path; Path('{stage}.txt').write_text('checked')"],
                'inputs': ['screenplay.md'], 'outputs': [f'{stage}.txt']}

    def save(self):
        self.path.write_text(json.dumps(self.c))

    def execute(self, stage):
        try:
            result = pipeline.run(self.path, stage)
        except ValueError as e:
            self.fail(f'Incremental stage {stage} was blocked: {e}')
        pipeline.approve(self.path, stage, 'user', 'Reviewed actual stage evidence')
        return result

    def test_incremental_production_creates_future_images_and_poses(self):
        # Full validation at entry would make forward production impossible.
        images = [a['image'] for a in self.c['assets'].values()]
        poses = self.c['actions']['walk']['paths']
        saved = {p: (self.root / p).read_bytes() for p in images + poses}
        for p in images + poses + ['cue.wav']:
            (self.root / p).unlink()
        self.c['project']['mode'] = 'formal'
        for a in self.c['assets'].values(): a['status'] = 'formal'
        self.c['graybox']['result'] = 'pending'
        self.c['stages']['graybox']['command'] = [sys.executable, '-c',
            "import json; from pathlib import Path; p=Path('2d-pipeline.json'); c=json.loads(p.read_text()); c['graybox']['result']='pass'; p.write_text(json.dumps(c)); Path('graybox.txt').write_text('layout checked')"]
        for stage, paths in [('assets', images), ('prepare', poses)]:
            code = 'from pathlib import Path; ' + '; '.join(
                f'Path({p!r}).write_bytes({saved[p]!r})' for p in paths)
            self.c['stages'][stage]['command'] = [sys.executable, '-c', code]
            self.c['stages'][stage]['outputs'] = paths
        self.save()
        self.execute('screenplay')
        self.execute('graybox')
        self.execute('assets')
        self.assertFalse((self.root / poses[0]).exists())
        self.execute('prepare')
        self.assertTrue((self.root / poses[0]).exists())
        self.assertFalse((self.root / 'cue.wav').exists())
        with self.assertRaisesRegex(ValueError, 'cue.wav'): contract.load(self.path)

    def test_downstream_changes_preserve_earlier_approvals(self):
        self.save()
        for stage in ['screenplay', 'graybox', 'assets', 'prepare']: self.execute(stage)
        self.c['assets']['actor']['image'] = 'art/new-actor.png'
        self.c['stages']['assets']['command'][-1] += '; print("new asset hook")'
        self.save()
        state = pipeline.status(self.path)
        self.assertEqual(state['stages']['screenplay']['status'], 'PASS')
        self.assertEqual(state['stages']['graybox']['status'], 'PASS')
        self.assertIn('screenplay', state['approvals'])
        self.assertIn('graybox', state['approvals'])
        self.assertEqual(state['stages']['assets']['status'], 'STALE')
        self.assertEqual(state['stages']['prepare']['status'], 'STALE')

    def test_sound_changes_only_invalidate_render_and_later(self):
        self.save()
        for stage in contract.STAGES[:7]: self.execute(stage)
        (self.root / 'cue.wav').write_bytes(b'changed sound')
        state = pipeline.status(self.path)
        self.assertEqual(state['stages']['build']['status'], 'PASS')
        self.assertIn('screenplay', state['approvals'])
        self.assertEqual(state['stages']['render']['status'], 'STALE')

    def test_hook_may_update_future_sound_plan(self):
        self.c['stages']['assets']['command'][-1] += "; import json; p=Path('2d-pipeline.json'); c=json.loads(p.read_text()); c['audio']['cues'][0]['path']='future.wav'; p.write_text(json.dumps(c))"
        self.save()
        for stage in ['screenplay', 'graybox', 'assets']: self.execute(stage)
        state = pipeline.status(self.path)
        self.assertIn('graybox', state['approvals'])

    def test_changed_upstream_evidence_invalidates_dependents(self):
        self.save()
        for stage in ['screenplay', 'graybox', 'assets']: self.execute(stage)
        (self.root / 'graybox.txt').write_text('different layout')
        state = pipeline.status(self.path)
        self.assertEqual(state['stages']['screenplay']['status'], 'PASS')
        self.assertEqual(state['stages']['graybox']['status'], 'STALE')
        self.assertEqual(state['stages']['assets']['status'], 'STALE')
        self.assertNotIn('assets', state['approvals'])

    def test_implicit_screenplay_input_cannot_be_mutated_by_hook(self):
        (self.root / 'brief.txt').write_text('input brief')
        self.c['stages']['screenplay']['inputs'] = ['brief.txt']
        self.c['stages']['screenplay']['command'][-1] += "; Path('screenplay.md').write_text('A different unreviewed story replaces the original story.')"
        self.save()
        with self.assertRaisesRegex(ValueError, 'inputs changed'):
            pipeline.run(self.path, 'screenplay')

    def test_missing_stage_products_and_pending_graybox_cannot_pass(self):
        self.c['graybox']['result'] = 'pending'
        self.save()
        self.execute('screenplay')
        with self.assertRaisesRegex(ValueError, 'graybox result'):
            pipeline.run(self.path, 'graybox')
        self.c['graybox']['result'] = 'pass'
        self.save()
        self.execute('graybox')
        (self.root / self.c['assets']['actor']['image']).unlink()
        with self.assertRaisesRegex(ValueError, 'missing file'):
            pipeline.run(self.path, 'assets')

    def test_prepared_file_change_keeps_asset_approval(self):
        self.save()
        for stage in ['screenplay', 'graybox', 'assets', 'prepare']: self.execute(stage)
        (self.root / self.c['actions']['walk']['paths'][0]).write_bytes(b'new pose')
        state = pipeline.status(self.path)
        self.assertIn('assets', state['approvals'])
        self.assertEqual(state['stages']['prepare']['status'], 'STALE')

    def test_hook_cannot_change_approved_story_contract(self):
        self.c['stages']['graybox']['command'][-1] += "; import json; p=Path('2d-pipeline.json'); c=json.loads(p.read_text()); c['events'][0]['result']='Different story outcome'; p.write_text(json.dumps(c))"
        self.save()
        self.execute('screenplay')
        with self.assertRaisesRegex(ValueError, 'upstream scene inputs'):
            pipeline.run(self.path, 'graybox')
        state = json.loads(pipeline.state_path(self.path).read_text())
        self.assertEqual(state['stages']['screenplay']['status'], 'STALE')
        self.assertNotIn('screenplay', state['approvals'])

    def test_prepare_requires_each_pose_alpha_before_passing(self):
        from PIL import Image
        self.save()
        for stage in ['screenplay', 'graybox', 'assets']: self.execute(stage)
        Image.new('RGBA', (24, 40), 'red').save(self.root / self.c['actions']['walk']['paths'][1])
        with self.assertRaisesRegex(ValueError, 'alpha'):
            pipeline.run(self.path, 'prepare')

    def test_failed_hook_cannot_leave_implicit_upstream_input_approved(self):
        self.c['stages']['graybox']['command'][-1] += "; Path('screenplay.md').write_text('erased'); raise SystemExit(1)"
        self.save()
        self.execute('screenplay')
        with self.assertRaises(ValueError): pipeline.run(self.path, 'graybox')
        state = json.loads(pipeline.state_path(self.path).read_text())
        self.assertEqual(state['stages']['screenplay']['status'], 'STALE')
        self.assertNotIn('screenplay', state['approvals'])
