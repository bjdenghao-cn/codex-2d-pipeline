import copy
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))

class EngineTests(unittest.TestCase):
    def setUp(self):
        try:
            self.contract = importlib.import_module('contract')
            self.fixture = importlib.import_module('fixture')
        except ImportError as exc:
            self.fail(f'Engine not implemented: {exc}')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = self.fixture.generate(self.root)
        self.config = json.loads(self.path.read_text())

    def test_variable_holds_boundaries(self):
        pose = self.contract.pose_at
        self.assertEqual([pose([3,5,2], i, False) for i in [0,2,3,7,8,9,10]], [0,0,1,1,2,2,2])
        self.assertEqual(pose([3,5,2], 10, True), 0)
        for bad in ([True], [0], [-1], []):
            with self.assertRaises(ValueError): pose(bad, 0, False)

    def test_fixture_and_unknown_event_actor(self):
        self.contract.validate(self.config, self.root)
        self.config['events'][0]['actor'] = 'missing'
        with self.assertRaisesRegex(ValueError, 'actor'): self.contract.validate(self.config, self.root)

    def test_uncovered_shot_and_cross_shot_conflict(self):
        self.config['shots'][1]['start'] += 1
        with self.assertRaisesRegex(ValueError, 'coverage'): self.contract.validate(self.config, self.root)
        self.config['shots'][1]['start'] -= 1
        self.config['shots'][1]['state_in']['barrier'] = 'wrong'
        with self.assertRaisesRegex(ValueError, 'continuity'): self.contract.validate(self.config, self.root)

    def test_missing_screenplay(self):
        (self.root / self.config['screenplay']).unlink()
        with self.assertRaisesRegex(ValueError, 'screenplay'): self.contract.validate(self.config, self.root)

    def test_formal_rejects_graybox_asset(self):
        self.config['project']['mode'] = 'formal'
        with self.assertRaisesRegex(ValueError, 'formal'): self.contract.validate(self.config, self.root)

    def test_invalid_transform_and_boolean_duration(self):
        self.config['instances'][0]['scale_keys'][0]['value'] = [-1, 1]
        with self.assertRaises(ValueError): self.contract.validate(self.config, self.root)
        self.config['instances'][0]['scale_keys'][0]['value'] = [1, 1]
        self.config['project']['frame_count'] = True
        with self.assertRaises(ValueError): self.contract.validate(self.config, self.root)

    def test_preparation_preserves_offsets_and_rejects_empty(self):
        prep = importlib.import_module('prepare')
        src = self.root / 'sheet.png'
        im = Image.new('RGBA', (20,10)); im.putpixel((3,5),(255,0,0,255)); im.putpixel((13,2),(255,0,0,255)); im.save(src)
        spec = {'source':'sheet.png','output':'prepared','expected_count':2,'canvas':[10,10], 'offset':[0,0], 'scale':1,'require_alpha':True,'crops':[[0,0,10,10],[10,0,20,10]]}
        result = prep.prepare(spec,self.root)
        self.assertEqual(Image.open(self.root / result['frames'][0]['path']).getbbox(), (3,5,4,6))
        self.assertEqual(Image.open(self.root / result['frames'][1]['path']).getbbox(), (3,2,4,3))
        im = Image.new('RGBA',(20,10)); im.save(src)
        spec['output']='empty'
        with self.assertRaisesRegex(ValueError,'transparent'): prep.prepare(spec,self.root)

    def test_missing_output_and_stale_approval_fail(self):
        runner = importlib.import_module('pipeline')
        stage = 'screenplay'
        self.config['stages'][stage] = {'command':[sys.executable,'-c','pass'], 'inputs':['screenplay.md'],'outputs':['absent.md'],'review':True}
        self.path.write_text(json.dumps(self.config))
        with self.assertRaisesRegex(ValueError,'output'): runner.run(self.path,stage,True)
        self.config['stages'][stage]['outputs']=['screenplay.md']
        self.path.write_text(json.dumps(self.config))
        runner.run(self.path,stage,False)
        runner.approve(self.path,stage,'user','Reviewed')
        (self.root/'screenplay.md').write_text('Changed story with a different ending.')
        state=runner.status(self.path)
        self.assertNotEqual(state['stages'][stage]['status'],'PASS')
        self.assertNotIn(stage,state['approvals'])

    def test_build_samples_visible_interval_and_camera(self):
        build = importlib.import_module('build')
        out=build.build(self.path)
        timeline=json.loads((out/'timeline.json').read_text())
        self.assertEqual(len(timeline['frames']),60)
        self.assertEqual(timeline['frames'][0]['items'][1]['position'],[30,140])
        self.assertEqual(timeline['frames'][59]['items'][1]['position'],[270,140])
        self.assertTrue((out/'runtime.gd').is_file())
        self.assertNotEqual(out,build.build(self.path))

    def test_render_missing_tool_records_failure(self):
        try: render=importlib.import_module('render')
        except ImportError as e: self.fail(f'Renderer not implemented: {e}')
        with self.assertRaises(ValueError): render.render(self.path,godot='does-not-exist-2d',ffmpeg='missing',ffprobe='missing',diagnostic=True)
        report=json.loads((self.root/'.2d-pipeline/render-status.json').read_text())
        self.assertEqual(report['status'],'FAIL')

    def test_verify_rejects_missing_movie(self):
        try: render=importlib.import_module('render')
        except ImportError as e: self.fail(f'Renderer not implemented: {e}')
        with self.assertRaisesRegex(ValueError,'missing'): render.verify(self.root/'absent.mp4',self.config['project'],'missing','missing')

    def test_unknown_schema_and_fields_rejected(self):
        for mutate in (lambda c:c.update(schema_version=2),lambda c:c['instances'][0].update(opacity=0.5)):
            c=copy.deepcopy(self.config); mutate(c)
            with self.assertRaises(ValueError): self.contract.validate(c,self.root)

    def test_event_audio_reference_and_actor_interval(self):
        self.config['events'][0]['audio']='missing-cue'
        with self.assertRaisesRegex(ValueError,'audio'): self.contract.validate(self.config,self.root)
        self.config['events'][0]['audio']='switch-tone'
        self.config['instances'][1]['end']=10
        with self.assertRaisesRegex(ValueError,'visible'): self.contract.validate(self.config,self.root)

    def test_missing_transparency_and_oversized_z(self):
        im=Image.new('RGBA',(24,40),'red'); im.save(self.root/'art/actor.png')
        with self.assertRaisesRegex(ValueError,'alpha'): self.contract.validate(self.config,self.root)

    def test_failure_invalidates_downstream_stage_status(self):
        runner=importlib.import_module('pipeline')
        command=[sys.executable,'-c','pass']
        for stage in ('screenplay','graybox'):
            self.config['stages'][stage]={'command':command,'inputs':['screenplay.md'],'outputs':['screenplay.md']}
        self.path.write_text(json.dumps(self.config))
        runner.run(self.path,'graybox',True)
        state=runner.status(self.path)
        state['stages']['screenplay']['status']='FAIL'
        runner.write_state(self.path,state)
        state=runner.status(self.path)
        self.assertNotEqual(state['stages']['graybox']['status'],'PASS')

    def test_failed_external_report_blocks_success(self):
        runner=importlib.import_module('pipeline')
        (self.root/'review.json').write_text('{"status":"FAIL","reason":"bad frames"}')
        self.config['stages']['screenplay']={'command':[sys.executable,'-c','pass'],'inputs':['screenplay.md'],'outputs':['review.json'],'report':'review.json'}
        self.path.write_text(json.dumps(self.config))
        with self.assertRaisesRegex(ValueError,'report failed'): runner.run(self.path,'screenplay')

    def test_prepare_rejects_opaque_rgba_source_when_alpha_required(self):
        prep=importlib.import_module('prepare')
        Image.new('RGBA',(10,10),'red').save(self.root/'opaque.png')
        spec={'source':'opaque.png','output':'prepared','expected_count':1,'canvas':[10,10],'offset':[0,0],'scale':1,'require_alpha':True,'crops':[[0,0,10,10]]}
        with self.assertRaisesRegex(ValueError,'alpha'): prep.prepare(spec,self.root)

    def test_executor_review_requires_explicit_project_authorization(self):
        runner=importlib.import_module('pipeline')
        self.config['stages']['screenplay']={'command':[sys.executable,'-c','pass'],'inputs':['screenplay.md'],'outputs':['screenplay.md']}
        self.path.write_text(json.dumps(self.config)); runner.run(self.path,'screenplay')
        with self.assertRaises(ValueError): runner.approve(self.path,'screenplay','executor','Checked screenplay')
        self.config['project']['review_policy']={'human_gates':['screenplay','assets','storyboard','review','release'],'executor_review_authorized':True,'authorization_note':'User explicitly delegated reviews for this project.'}
        self.path.write_text(json.dumps(self.config)); runner.run(self.path,'screenplay')
        state=runner.approve(self.path,'screenplay','executor','Checked story causality and output hash')
        self.assertEqual(state['approvals']['screenplay']['actor'],'executor')
        self.assertIn('authorization_note',state['approvals']['screenplay'])

    def test_not_required_graybox_records_skip_without_hook(self):
        runner=importlib.import_module('pipeline')
        self.config['graybox']={'required':False,'reason':'Simple scene has no timing risk','result':'not_required'}
        self.config['stages']['screenplay']={'command':[sys.executable,'-c','pass'],'inputs':['screenplay.md'],'outputs':['screenplay.md']}
        self.path.write_text(json.dumps(self.config)); runner.run(self.path,'screenplay'); runner.approve(self.path,'screenplay','user','Approved story')
        state=runner.run(self.path,'graybox')
        self.assertEqual(state['stages']['graybox']['status'],'PASS')
        self.assertEqual(state['stages']['graybox']['decision'],'not_required')

    def test_hook_mutation_of_approved_upstream_output_stops_same_run(self):
        runner=importlib.import_module('pipeline')
        (self.root/'approved-story.txt').write_text('Approved interpretation')
        self.config['project']['review_policy']={'human_gates':['screenplay'],'executor_review_authorized':False,'authorization_note':'Only screenplay requires human review for this diagnostic.'}
        self.config['stages']['screenplay']={'command':[sys.executable,'-c','pass'],'inputs':['screenplay.md'],'outputs':['approved-story.txt']}
        self.config['stages']['graybox']={'command':[sys.executable,'-c',"from pathlib import Path; Path('approved-story.txt').write_text('Unreviewed replacement')"],'inputs':['screenplay.md'],'outputs':['approved-story.txt']}
        self.config['stages']['assets']={'command':[sys.executable,'-c',"from pathlib import Path; Path('should-not-run.txt').write_text('ran')"],'inputs':['screenplay.md'],'outputs':['should-not-run.txt']}
        self.path.write_text(json.dumps(self.config))
        runner.run(self.path,'screenplay'); runner.approve(self.path,'screenplay','user','Approved interpretation')
        with self.assertRaisesRegex(ValueError,'upstream output'): runner.run(self.path,'assets')
        state=json.loads(runner.state_path(self.path).read_text())
        self.assertEqual(state['stages']['screenplay']['status'],'STALE')
        self.assertEqual(state['stages']['graybox']['status'],'FAIL')
        self.assertNotIn('screenplay',state['approvals'])
        self.assertFalse((self.root/'should-not-run.txt').exists())

    def test_mixed_sheet_opaque_crop_rejected_before_output_creation(self):
        prep=importlib.import_module('prepare')
        sheet=Image.new('RGBA',(20,10),'red'); sheet.putpixel((19,9),(0,0,0,0)); sheet.save(self.root/'mixed.png')
        spec={'source':'mixed.png','output':'prepared','expected_count':1,'canvas':[10,10],'offset':[0,0],'scale':1,'require_alpha':True,'crops':[[0,0,10,10]]}
        with self.assertRaisesRegex(ValueError,'alpha'): prep.prepare(spec,self.root)
        self.assertFalse((self.root/'prepared').exists())

if __name__ == '__main__': unittest.main()
