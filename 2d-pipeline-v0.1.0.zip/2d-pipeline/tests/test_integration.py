"""Opt in with PIPELINE_GODOT, PIPELINE_FFMPEG, PIPELINE_FFPROBE."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from fixture import generate
from render import render, verify, execute
from PIL import Image

@unittest.skipUnless(all(os.environ.get('PIPELINE_'+t) for t in ('GODOT','FFMPEG','FFPROBE')), 'UNVERIFIED: local tool paths not provided')
class IntegrationTests(unittest.TestCase):
    def test_portrait_render_uses_exact_canvas_beyond_desktop_height(self):
        with tempfile.TemporaryDirectory() as tmp:
            config=generate(Path(tmp))
            scene=json.loads(config.read_text()); scene['project']['resolution']=[1080,1920]
            config.write_text(json.dumps(scene))
            tools={t:os.environ['PIPELINE_'+t.upper()] for t in ('godot','ffmpeg','ffprobe')}
            try: result=render(config,diagnostic=True,**tools)
            except ValueError as exc: self.fail(f'Native portrait render must succeed: {exc}')
            with Image.open(Path(result['project'])/'frames/frame-000000.png') as im:
                self.assertEqual(im.size,(1080,1920))
                self.assertEqual(im.getpixel((555,1010))[:3],(172,51,66))
            self.assertEqual(result['probe']['streams'][0]['width'],1080)
            self.assertEqual(result['probe']['streams'][0]['height'],1920)

    def test_actual_pixels_audio_and_repeat_determinism(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); config=generate(root)
            tools={t:os.environ['PIPELINE_'+t.upper()] for t in ('godot','ffmpeg','ffprobe')}
            first=render(config,diagnostic=True,**tools)
            second=render(config,diagnostic=True,**tools)
            self.assertEqual(first['frames'],second['frames'])
            frames=Path(first['project'])/'frames'
            with Image.open(frames/'frame-000000.png') as im: self.assertEqual(im.getpixel((175,170))[:3],(172,51,66))
            with Image.open(frames/'frame-000040.png') as im: self.assertEqual(im.getpixel((175,170))[:3],(214,233,240))
            audio=[s for s in first['probe']['streams'] if s['codec_type']=='audio']
            self.assertEqual(audio[0]['codec_name'],'aac')
            silent=root/'stripped.mp4'
            execute([tools['ffmpeg'],'-v','error','-i',first['movie'],'-an','-c:v','copy',str(silent)])
            project=json.loads(config.read_text())['project']
            with self.assertRaisesRegex(ValueError,'audio'):
                verify(silent,project,tools['ffmpeg'],tools['ffprobe'],expected_audio=True)
