"""Build a fresh Godot project with an integer-frame sampled timeline."""
import argparse
import json
from pathlib import Path
import shutil
import uuid
from contract import load, local, pose_at, sample, sha

def build(config):
    config=Path(config).resolve(); c=load(config); root=config.parent
    out=root/'outputs'/f'godot-{uuid.uuid4().hex[:12]}'
    out.mkdir(parents=True); (out/'images').mkdir(); (out/'frames').mkdir()
    copied={}
    def copy_image(path):
        if path not in copied:
            source=local(root,path); dest='images/'+sha(source)+'.png'
            shutil.copyfile(source,out/dest); copied[path]=dest
        return copied[path]
    frames=[]
    for f in range(c['project']['frame_count']):
        shot=next(s for s in c['shots'] if s['start']<=f<s['end'])
        items=[]
        for ins in sorted(c['instances'],key=lambda x:x['z']):
            if not ins['start']<=f<ins['end']: continue
            path=c['assets'][ins['asset']]['image']
            if ins.get('action'):
                action=c['actions'][ins['action']]; path=action['paths'][pose_at(action['holds'],f-ins['start'],action['loop'])]
            items.append({'id':ins['id'],'image':copy_image(path),'position':sample(ins['position_keys'],f),'scale':sample(ins['scale_keys'],f),'rotation':sample(ins['rotation_keys'],f),'z':ins['z']})
        frames.append({'frame':f,'shot':shot['id'],'camera_position':sample(shot['camera']['position_keys'],f),'camera_zoom':sample(shot['camera']['zoom_keys'],f),'items':items})
    timeline={'project':c['project'],'frames':frames,'input_sha256':sha(config)}
    (out/'timeline.json').write_text(json.dumps(timeline),encoding='utf-8')
    shutil.copyfile(Path(__file__).resolve().parents[1]/'assets/godot/runtime.gd',out/'runtime.gd')
    w,h=c['project']['resolution']
    (out/'project.godot').write_text(f'config_version=5\n[application]\nconfig/name="2D offline renderer"\nrun/main_scene="res://main.tscn"\n[display]\nwindow/size/viewport_width={w}\nwindow/size/viewport_height={h}\nwindow/size/window_width_override={w}\nwindow/size/window_height_override={h}\n[rendering]\nrenderer/rendering_method="gl_compatibility"\ntextures/default_filters/use_nearest_mipmap_filter=false\nenvironment/defaults/default_clear_color=Color(0,0,0,1)\n',encoding='utf-8')
    (out/'main.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://runtime.gd" id="1"]\n[node name="OfflineRenderer" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--config',type=Path,required=True); a=p.parse_args()
    try: print(build(a.config))
    except (ValueError,OSError) as e: p.exit(1,f'FAIL: {e}\n')
