"""Offline Godot PNG readback, frame-anchored audio, H.264 encoding and QC."""
import argparse
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
from PIL import Image
from build import build
from contract import load, local, sha

def tool(value,fallback):
    found=shutil.which(value or fallback)
    if not found: raise ValueError(f'missing tool: {value or fallback}')
    return found

def execute(command,timeout=300,cwd=None):
    try: result=subprocess.run(command,cwd=cwd,shell=False,capture_output=True,text=True,timeout=timeout)
    except (OSError,subprocess.SubprocessError) as e: raise ValueError(f'process failed: {e}') from e
    if result.returncode: raise ValueError(f'process exit {result.returncode}: {result.stderr[-3000:]} {result.stdout[-1000:]}')
    return result.stdout

def verify(movie,project,ffmpeg,ffprobe,expected_audio=False):
    if not Path(movie).is_file(): raise ValueError('missing rendered movie')
    result=json.loads(execute([ffprobe,'-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]))
    stream=next((s for s in result['streams'] if s['codec_type']=='video'),None)
    if not stream: raise ValueError('missing video stream')
    if [stream['width'],stream['height']]!=project['resolution']: raise ValueError('resolution verification failed')
    if Fraction(stream['avg_frame_rate'])!=project['fps']: raise ValueError('fps verification failed')
    if int(stream.get('nb_read_frames',-1))!=project['frame_count']: raise ValueError('frame count verification failed')
    expected=project['frame_count']/project['fps']
    if abs(float(stream['duration'])-expected)>1/project['fps']+0.001: raise ValueError('duration verification failed')
    if stream['codec_name']!='h264' or stream['pix_fmt']!='yuv420p': raise ValueError('encoding verification failed')
    audio=[s for s in result['streams'] if s['codec_type']=='audio']
    if expected_audio:
        if len(audio)!=1 or audio[0]['codec_name']!='aac': raise ValueError('missing or invalid AAC audio stream')
        if abs(float(audio[0]['duration'])-expected)>1/project['fps']+0.03: raise ValueError('audio duration verification failed')
    elif audio: raise ValueError('unexpected audio in explicit silent movie')
    execute([ffmpeg,'-v','error','-xerror','-i',str(movie),'-f','null','-'])
    return result

def mix_audio(c,root,out,ffmpeg,ffprobe):
    if c['audio']['silence']: return None
    fps=c['project']['fps']; total=c['project']['frame_count']/fps
    command=[ffmpeg,'-v','error','-n']
    filters=[]; labels=[]
    for i,cue in enumerate(c['audio']['cues']):
        path=local(root,cue['path'])
        probe=json.loads(execute([ffprobe,'-v','error','-show_streams','-show_format','-of','json',str(path)]))
        if not any(s['codec_type']=='audio' for s in probe['streams']): raise ValueError('cue has no audio stream')
        duration=cue['duration']/fps
        if float(probe['format']['duration'])+0.001<duration: raise ValueError('cue source shorter than declared duration')
        command+=['-i',str(path)]
        # Delay in samples avoids rounding frame starts to milliseconds.
        delay=round(cue['start']*48000/fps)
        filters.append(f'[{i}:a]aresample=48000,atrim=duration={duration},asetpts=PTS-STARTPTS,volume={cue["volume"]},adelay={delay}S:all=1[a{i}]')
        labels.append(f'[a{i}]')
    filters.append(''.join(labels)+f'amix=inputs={len(labels)}:normalize=0,apad,atrim=duration={total}[mix]')
    dest=out/'audio.wav'
    execute(command+['-filter_complex',';'.join(filters),'-map','[mix]','-ar','48000','-ac','2',str(dest)])
    return dest

def render(config,godot=None,ffmpeg=None,ffprobe=None,diagnostic=False,timeout=300):
    config=Path(config).resolve(); report_path=config.parent/'.2d-pipeline/render-status.json'; report_path.parent.mkdir(parents=True,exist_ok=True)
    report={'status':'FAIL'}
    try:
        c=load(config)
        if c['project']['test_only'] and not diagnostic: raise ValueError('TEST_ONLY render requires --diagnostic')
        if diagnostic and not c['project']['test_only']: raise ValueError('diagnostic bypass only supports TEST_ONLY projects')
        godot=tool(godot,'godot'); ffmpeg=tool(ffmpeg,'ffmpeg'); ffprobe=tool(ffprobe,'ffprobe')
        versions={'godot':execute([godot,'--version']).strip(),'ffmpeg':execute([ffmpeg,'-version']).splitlines()[0],'ffprobe':execute([ffprobe,'-version']).splitlines()[0]}
        if not versions['godot'].startswith('4.'): raise ValueError('Godot 4 required')
        out=build(config); report['project']=str(out)
        # Headless Godot uses a dummy renderer and cannot capture actual viewport pixels.
        # Use an off-screen compatibility window and real GPU readback.
        log=execute([godot,'--path',str(out),'--rendering-method','gl_compatibility','--position','-10000,-10000','--fixed-fps',str(c['project']['fps']),'--disable-vsync'],timeout=timeout,cwd=out)
        (out/'godot.log').write_text(log,encoding='utf-8')
        runtime=out/'runtime-status.json'
        if not runtime.is_file() or json.loads(runtime.read_text()).get('status')!='PASS': raise ValueError('missing or failed Godot runtime report')
        files=sorted((out/'frames').glob('frame-*.png'))
        if len(files)!=c['project']['frame_count']: raise ValueError('Godot output frame count mismatch')
        for i,file in enumerate(files):
            if file.name!=f'frame-{i:06d}.png': raise ValueError('frame sequence gap')
            with Image.open(file) as im:
                if list(im.size)!=c['project']['resolution']: raise ValueError('frame resolution mismatch')
                im.load()
        audio=mix_audio(c,config.parent,out,ffmpeg,ffprobe)
        movie=out/('TEST_ONLY-diagnostic.mp4' if diagnostic else 'render-review.mp4')
        command=[ffmpeg,'-v','error','-n','-framerate',str(c['project']['fps']),'-i',str(out/'frames/frame-%06d.png')]
        if audio: command+=['-i',str(audio)]
        command+=['-map','0:v:0']
        if audio: command+=['-map','1:a:0','-c:a','aac','-b:a','192k']
        command+=['-c:v','libx264','-pix_fmt','yuv420p','-frames:v',str(c['project']['frame_count']),'-r',str(c['project']['fps']),'-movflags','+faststart',str(movie)]
        execute(command,timeout=timeout)
        probe=verify(movie,c['project'],ffmpeg,ffprobe,expected_audio=audio is not None)
        report.update(status='PASS',acceptance='TECHNICAL_ONLY',test_only=c['project']['test_only'],movie=str(movie),sha256=sha(movie),frames={p.name:sha(p) for p in files},versions=versions,probe=probe)
    except (ValueError,OSError,KeyError,StopIteration,json.JSONDecodeError) as e:
        report['error']=str(e); report_path.write_text(json.dumps(report,indent=2),encoding='utf-8'); raise ValueError(str(e)) from e
    report_path.write_text(json.dumps(report,indent=2),encoding='utf-8'); return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--config',type=Path,required=True)
    for name in ('godot','ffmpeg','ffprobe'): p.add_argument('--'+name)
    p.add_argument('--diagnostic',action='store_true'); p.add_argument('--timeout',type=int,default=300); a=p.parse_args()
    try: print(json.dumps(render(**vars(a)),indent=2))
    except ValueError as e: p.exit(1,f'FAIL: {e}\n')
