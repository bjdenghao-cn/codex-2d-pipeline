"""Strict, frame-based local scene contract. Intervals are [start, end)."""
import hashlib
import json
import math
from pathlib import Path
from PIL import Image

STAGES = ['screenplay','graybox','assets','prepare','storyboard','build','render','review','release']
HUMAN_GATES = ['screenplay','graybox','assets','storyboard','review','release']

def integer(value, name, minimum=0):
    if type(value) is not int or value < minimum: raise ValueError(f'{name}: expected integer >= {minimum}')
    return value

def number(value, name, positive=False):
    if type(value) not in (int,float) or not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f'{name}: invalid finite numeric value')
    return value

def local(root, value, exists=True):
    if not isinstance(value,str) or not value.strip(): raise ValueError('path must be nonempty')
    path=(Path(root)/value).resolve()
    if not path.is_relative_to(Path(root).resolve()): raise ValueError(f'path escapes workspace: {value}')
    if exists and not path.is_file(): raise ValueError(f'missing file: {value}')
    return path

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pose_at(holds, frame, loop=False):
    integer(frame,'frame')
    if not holds: raise ValueError('holds must not be empty')
    for h in holds: integer(h,'hold',1)
    if type(loop) is not bool: raise ValueError('loop must be boolean')
    cursor=frame % sum(holds) if loop else min(frame,sum(holds)-1)
    for i,h in enumerate(holds):
        if cursor<h: return i
        cursor-=h

def keys(values, count, dimensions, name, positive=False):
    if not isinstance(values,list) or not values: raise ValueError(f'{name}: keys required')
    previous=-1
    for key in values:
        fields(key,'frame value',name)
        f=integer(key['frame'],name)
        if f<=previous or f>=count: raise ValueError(f'{name}: keys out of order/range')
        previous=f
        v=key['value']
        if dimensions:
            if not isinstance(v,list) or len(v)!=dimensions: raise ValueError(f'{name}: wrong dimensions')
            for item in v: number(item,name,positive)
        else: number(v,name,positive)

def sample(values,frame):
    if frame<=values[0]['frame']: return values[0]['value']
    for a,b in zip(values,values[1:]):
        if frame<=b['frame']:
            t=(frame-a['frame'])/(b['frame']-a['frame'])
            if isinstance(a['value'],list): return [x+(y-x)*t for x,y in zip(a['value'],b['value'])]
            return a['value']+(b['value']-a['value'])*t
    return values[-1]['value']

def check_image(path,alpha):
    with Image.open(path) as im:
        if alpha and im.mode!='RGBA': raise ValueError(f'RGBA alpha required: {path}')
        if alpha and im.getchannel('A').getextrema()[0]==255: raise ValueError(f'alpha transparency required: {path}')
        if im.convert('RGBA').getchannel('A').getbbox() is None: raise ValueError(f'fully transparent image: {path}')

def fields(obj,allowed,name):
    if not isinstance(obj,dict): raise ValueError(f'{name}: expected object')
    extra=set(obj)-set(allowed.split())
    if extra: raise ValueError(f'{name}: unsupported fields {sorted(extra)}')

def validate(c,root,ready='all'):
    try:
        fields(c,'schema_version project screenplay graybox shots assets actions instances events audio stages','scene')
        if type(c['schema_version']) is not int or c['schema_version']!=1: raise ValueError('unsupported schema_version')
        fields(c['project'],'name fps frame_count resolution mode test_only review_policy','project')
        policy=c['project'].get('review_policy')
        if policy is not None:
            fields(policy,'human_gates executor_review_authorized authorization_note','review_policy')
            if not isinstance(policy['human_gates'],list) or len(set(policy['human_gates']))!=len(policy['human_gates']) or any(x not in STAGES for x in policy['human_gates']): raise ValueError('invalid review human_gates')
            if type(policy['executor_review_authorized']) is not bool: raise ValueError('executor review authorization must be boolean')
            if not isinstance(policy['authorization_note'],str) or not policy['authorization_note'].strip(): raise ValueError('explicit project review authorization note required')
        fields(c['graybox'],'required reason result','graybox')
        fields(c['audio'],'silence cues','audio')
        p=c['project']; n=integer(p['frame_count'],'frame_count',1); integer(p['fps'],'fps',1)
        if len(p['resolution'])!=2: raise ValueError('resolution needs width,height')
        for x in p['resolution']:
            integer(x,'resolution',2)
            if x%2: raise ValueError('H.264 resolution must be even')
        if p['mode'] not in ('formal','graybox'): raise ValueError('invalid mode')
        if type(p['test_only']) is not bool: raise ValueError('test_only must be boolean')
        try: screenplay=local(root,c['screenplay']).read_text(encoding='utf-8')
        except (ValueError,OSError) as e: raise ValueError(f'screenplay: {e}') from e
        if len(screenplay.strip())<30: raise ValueError('screenplay requires real story content')
        g=c['graybox']
        if type(g['required']) is not bool or not g['reason'].strip() or g['result'] not in ('pending','pass','not_required'): raise ValueError('graybox decision incomplete')
        if ready!='plan' and g['required'] and p['mode']=='formal' and g['result']!='pass': raise ValueError('graybox result required')
        cursor=0; previous={}; shot_ids=set()
        for shot in c['shots']:
            fields(shot,'id start end state_in state_out camera','shot')
            fields(shot['camera'],'position_keys zoom_keys','camera')
            if shot['id'] in shot_ids: raise ValueError('duplicate shot id')
            shot_ids.add(shot['id'])
            start=integer(shot['start'],'shot start'); end=integer(shot['end'],'shot end',1)
            if start!=cursor or end<=start or end>n: raise ValueError('shot coverage gap/overlap')
            for k,v in shot['state_in'].items():
                if k in previous and previous[k]!=v: raise ValueError(f'shot continuity conflict: {k}')
            previous=shot['state_out']; cursor=end
            keys(shot['camera']['position_keys'],n,2,'camera position')
            keys(shot['camera']['zoom_keys'],n,2,'camera zoom',True)
        if cursor!=n: raise ValueError('shot coverage must end at frame_count')
        for aid,a in c['assets'].items():
            fields(a,'type image source status require_alpha','asset')
            if a['type'] not in ('character','scenery','prop','effect'): raise ValueError('unsupported asset type')
            if a['status'] not in ('formal','graybox','test'): raise ValueError('invalid asset status')
            if ready!='plan' and p['mode']=='formal' and a['status']!='formal': raise ValueError(f'formal scene uses nonformal asset {aid}')
            if not a['source'].strip(): raise ValueError('asset source required')
            if type(a['require_alpha']) is not bool: raise ValueError('require_alpha must be boolean')
            file=local(root,a['image'],exists=ready!='plan')
            if ready!='plan': check_image(file,a['require_alpha'])
        for aid,a in c['actions'].items():
            fields(a,'owner paths holds expected_count loop','action')
            if a['owner'] not in c['assets']: raise ValueError(f'unknown action owner: {aid}')
            integer(a['expected_count'],'expected_count',1)
            if len(a['paths'])!=a['expected_count'] or len(a['holds'])!=a['expected_count']: raise ValueError('action frame count mismatch')
            pose_at(a['holds'],0,a['loop'])
            sizes=[]
            for path in a['paths']:
                file=local(root,path,exists=ready in ('poses','all'))
                if ready in ('poses','all'):
                    check_image(file,c['assets'][a['owner']]['require_alpha'])
                    with Image.open(file) as im: sizes.append(im.size)
            if sizes and len(set(sizes))!=1: raise ValueError('action canvas sizes differ')
        ids=set()
        for ins in c['instances']:
            fields(ins,'id asset action start end position_keys scale_keys rotation_keys z','instance')
            if ins['id'] in ids: raise ValueError('duplicate instance id')
            ids.add(ins['id'])
            if ins['asset'] not in c['assets']: raise ValueError('unknown instance asset')
            if ins.get('action'):
                if ins['action'] not in c['actions'] or c['actions'][ins['action']]['owner']!=ins['asset']: raise ValueError('unknown/mismatched action')
            start=integer(ins['start'],'instance start'); end=integer(ins['end'],'instance end',1)
            if not start<end<=n: raise ValueError('instance interval invalid')
            if type(ins['z']) is not int: raise ValueError('z must be integer')
            if not -4096<=ins['z']<=4096: raise ValueError('z outside Godot supported range')
            keys(ins['position_keys'],n,2,'position'); keys(ins['scale_keys'],n,2,'scale',True); keys(ins['rotation_keys'],n,0,'rotation')
        for ev in c['events']:
            fields(ev,'id actor target start end cause response result audio','event')
            for role in ('actor','target'):
                if ev[role] not in ids: raise ValueError(f'unknown event {role}')
            start=integer(ev['start'],'event start'); end=integer(ev['end'],'event end',1)
            if not start<end<=n: raise ValueError('event interval invalid')
            for role in ('actor','target'):
                instance=next(i for i in c['instances'] if i['id']==ev[role])
                if instance['start']>start or instance['end']<end: raise ValueError(f'event {role} not visible throughout interval')
            if ev.get('audio') and ev['audio'] not in [q.get('id') for q in c['audio']['cues']]: raise ValueError('unknown event audio cue')
            for field in ('cause','response','result'):
                if not isinstance(ev[field],str) or not ev[field].strip(): raise ValueError(f'event {field} required')
        if not c['events']: raise ValueError('story events required')
        audio=c['audio']
        if type(audio['silence']) is not bool: raise ValueError('audio silence must be explicit')
        if not audio['silence'] and not audio['cues']: raise ValueError('audio cues required unless explicit silence')
        if audio['silence'] and audio['cues']: raise ValueError('silence conflicts with cues')
        for cue in audio['cues']:
            fields(cue,'id path start duration volume','audio cue')
            local(root,cue['path'],exists=ready=='all'); start=integer(cue['start'],'audio start'); duration=integer(cue['duration'],'audio duration',1)
            if start+duration>n: raise ValueError('audio outside timeline')
            number(cue['volume'],'audio volume')
            if cue['volume']<0: raise ValueError('negative audio volume')
        for name,spec in c['stages'].items():
            if name not in STAGES: raise ValueError(f'unknown stage: {name}')
            fields(spec,'command inputs outputs review timeout report','stage')
            if 'review' in spec and spec['review'] is not True: raise ValueError('production stages require human review')
        return c
    except (KeyError,TypeError,AttributeError) as e: raise ValueError(f'malformed scene: {e}') from e

def load(path,ready='all'):
    path=Path(path).resolve()
    try: c=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError) as e: raise ValueError(f'config: {e}') from e
    return validate(c,path.parent,ready)

def stage_ready(c,root,stage,completed=False):
    """Validate consumed resources before execution and produced resources after it."""
    i=STAGES.index(stage)
    if i>=6: ready='all'
    elif i>=4 or (stage=='prepare' and completed): ready='poses'
    elif i>=3 or (stage=='assets' and completed): ready='assets'
    else: ready='plan'
    validate(c,root,ready)
    if ((stage=='graybox' and completed) or i>=2) and c['graybox']['required'] and c['graybox']['result']!='pass':
        raise ValueError('graybox result required')

def dependencies(c):
    result={c['screenplay']}
    result.update(a['image'] for a in c['assets'].values())
    for a in c['actions'].values(): result.update(a['paths'])
    result.update(a['path'] for a in c['audio']['cues'])
    return sorted(result)
