"""Explicit rectangle preparation; no per-pose fitting or recentering."""
import argparse
import json
from pathlib import Path
from PIL import Image
from contract import integer, number, local, sha, check_image

def prepare(spec,root):
    root=Path(root); source=local(root,spec['source']); dest=local(root,spec['output'],False)
    if type(spec['require_alpha']) is not bool: raise ValueError('require_alpha must be boolean')
    check_image(source,spec['require_alpha'])
    if dest.exists(): raise ValueError('output already exists; choose a fresh directory (source overwrite forbidden)')
    integer(spec['expected_count'],'expected_count',1)
    if len(spec['crops'])!=spec['expected_count']: raise ValueError('crop count mismatch')
    canvas=spec['canvas']; offset=spec['offset']; scale=number(spec['scale'],'scale',True)
    if len(canvas)!=2 or len(offset)!=2: raise ValueError('canvas/offset need two values')
    for x in canvas: integer(x,'canvas',1)
    for x in offset:
        if type(x) is not int: raise ValueError('offset must be integer')
    prepared=[]
    with Image.open(source) as image:
        if spec['require_alpha'] and image.mode!='RGBA': raise ValueError('source must actually be RGBA')
        for rect in spec['crops']:
            if len(rect)!=4: raise ValueError('crop requires four edges')
            for x in rect: integer(x,'crop edge')
            x,y,r,b=rect
            if not x<r<=image.width or not y<b<=image.height: raise ValueError('crop clipping/outside source')
            pose=image.crop(rect).convert('RGBA'); size=(round(pose.width*scale),round(pose.height*scale))
            if min(size)<1: raise ValueError('scale produces empty frame')
            pose=pose.resize(size,Image.Resampling.LANCZOS)
            if offset[0]<0 or offset[1]<0 or offset[0]+size[0]>canvas[0] or offset[1]+size[1]>canvas[1]: raise ValueError('canvas clipping')
            out=Image.new('RGBA',tuple(canvas)); out.alpha_composite(pose,tuple(offset))
            if out.getchannel('A').getbbox() is None: raise ValueError('fully transparent output')
            if spec['require_alpha'] and out.getchannel('A').getextrema()[0]==255: raise ValueError('prepared output requires alpha transparency')
            prepared.append(out)
    dest.mkdir(parents=True)
    frames=[]
    for i,im in enumerate(prepared):
        path=dest/f'pose-{i:04d}.png'; im.save(path); frames.append({'path':path.relative_to(root).as_posix(),'sha256':sha(path)})
    contact=Image.new('RGBA',(canvas[0]*len(prepared),canvas[1]))
    for i,im in enumerate(prepared): contact.alpha_composite(im,(canvas[0]*i,0))
    contact.save(dest/'contact-sheet-TECHNICAL-ONLY.png')
    result={'source':spec['source'],'source_sha256':sha(source),'canvas':canvas,'offset':offset,'scale':scale,'frames':frames}
    (dest/'manifest.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--spec',type=Path,required=True); args=p.parse_args()
    try: print(json.dumps(prepare(json.loads(args.spec.read_text()),args.spec.resolve().parent),indent=2))
    except (ValueError,OSError,KeyError) as e: p.exit(1,f'FAIL: {e}\n')
