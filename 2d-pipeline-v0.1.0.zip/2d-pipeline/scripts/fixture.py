"""Generate a small TEST_ONLY complete story; never production artwork."""
import argparse
import json
import math
from pathlib import Path
import struct
import wave
from PIL import Image, ImageDraw

def key(value,frame=0): return {'frame':frame,'value':value}

def generate(root):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    if (root/'2d-pipeline.json').exists(): raise ValueError('fixture config exists')
    (root/'art').mkdir(exist_ok=True)
    assets={}
    for name,size,color,kind in [('scene',(320,240),'#d6e9f0','scenery'),('actor',(24,40),'#ed8b24','character'),('barrier',(14,90),'#ac3342','prop'),('switch',(14,14),'#37a475','prop'),('spark',(18,18),'#ffee32','effect')]:
        im=Image.new('RGBA',size,color if name=='scene' else (0,0,0,0)); d=ImageDraw.Draw(im)
        if name!='scene': d.rectangle((2,2,size[0]-3,size[1]-3),fill=color)
        else:
            d.rectangle((0,180,319,239),fill='#768d6e'); d.rectangle((282,130,318,180),fill='#5bb779'); d.text((5,5),'TEST ONLY - SWITCH AND BARRIER',fill='black')
        im.save(root/'art'/f'{name}.png')
        assets[name]={'type':kind,'image':f'art/{name}.png','source':'synthetic diagnostic fixture','status':'test','require_alpha':name!='scene'}
    for i in range(3):
        im=Image.new('RGBA',(24,40)); d=ImageDraw.Draw(im); d.ellipse((6,2,18,14),fill='#ed8b24'); d.rectangle((7,14,17,29),fill='#ed8b24'); d.line((10,29,4+i*3,38),fill='#283657',width=3); d.line((14,29,20-i*3,38),fill='#283657',width=3)
        im.save(root/'art'/f'walk-{i}.png')
    with wave.open(str(root/'cue.wav'),'wb') as w:
        w.setparams((1,2,48000,0,'NONE','not compressed'))
        w.writeframes(b''.join(struct.pack('<h',int(5000*math.sin(2*math.pi*660*i/48000))) for i in range(4800)))
    (root/'screenplay.md').write_text('# TEST ONLY — Switch and barrier\n\nShot 1 (frames 0–29): The traveller approaches a closed barrier, sees the obstruction, stops by the switch and operates it. A flash and tone mark activation.\n\nShot 2 (frames 30–59): Keeping the traveller and barrier continuous, the barrier rises. The traveller crosses the cleared path and reaches the green destination.\n',encoding='utf-8')
    def instance(name,pos,z,start=0,end=60): return {'id':name,'asset':name,'start':start,'end':end,'position_keys':[key(pos)],'scale_keys':[key([1,1])],'rotation_keys':[key(0)],'z':z}
    instances=[instance('scene',[0,0],0),instance('actor',[30,140],2),instance('barrier',[170,90],3),instance('switch',[135,155],3),instance('spark',[133,130],4,24,31)]
    instances[1].update(action='walk',position_keys=[key([30,140]),key([125,140],20),key([125,140],35),key([270,140],59)])
    instances[2]['position_keys']=[key([170,90]),key([170,90],29),key([170,-20],40)]
    camera={'position_keys':[key([160,120])],'zoom_keys':[key([1,1])]}
    c={'schema_version':1,'project':{'name':'TEST_ONLY_switch_story','fps':30,'frame_count':60,'resolution':[320,240],'mode':'graybox','test_only':True},'screenplay':'screenplay.md','graybox':{'required':True,'reason':'Validate cause-response timing using synthetic art','result':'pass'},'shots':[{'id':'approach','start':0,'end':30,'state_in':{'barrier':'closed'},'state_out':{'barrier':'opening'},'camera':camera},{'id':'cross','start':30,'end':60,'state_in':{'barrier':'opening'},'state_out':{'barrier':'open','actor':'destination'},'camera':camera}], 'assets':assets,'actions':{'walk':{'owner':'actor','paths':[f'art/walk-{i}.png' for i in range(3)],'holds':[3,5,2],'expected_count':3,'loop':True}},'instances':instances,'events':[{'id':'activate','actor':'actor','target':'switch','start':20,'end':30,'cause':'The closed barrier blocks progress','response':'Traveller stops and operates switch','result':'Switch activates with flash and tone','audio':'switch-tone'},{'id':'open','actor':'switch','target':'barrier','start':30,'end':41,'cause':'Switch was activated','response':'Barrier rises','result':'Path becomes clear'},{'id':'arrive','actor':'actor','target':'scene','start':41,'end':60,'cause':'Path is now clear','response':'Traveller crosses barrier','result':'Traveller reaches destination'}],'audio':{'silence':False,'cues':[{'id':'switch-tone','path':'cue.wav','start':24,'duration':3,'volume':0.8}]},'stages':{}}
    path=root/'2d-pipeline.json'; path.write_text(json.dumps(c,indent=2),encoding='utf-8'); return path

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--workspace',type=Path,required=True); a=p.parse_args()
    try: print(generate(a.workspace))
    except (ValueError,OSError) as e: p.exit(1,f'FAIL: {e}\n')
