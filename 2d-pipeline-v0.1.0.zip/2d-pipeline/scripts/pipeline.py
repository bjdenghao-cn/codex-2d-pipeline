"""Fail-closed local production stages and content-bound review approvals."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from contract import STAGES, HUMAN_GATES, load, local, sha, integer, stage_ready

def state_path(config): return Path(config).resolve().parent/'.2d-pipeline/run-state.json'

def write_state(config,state):
    path=state_path(config); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp'); temp.write_text(json.dumps(state,indent=2),encoding='utf-8'); temp.replace(path)

def hashes(root,paths): return {p:sha(local(root,p)) for p in paths}

def stage_contract(c,name):
    """Ownership follows production order; downstream plans are not story inputs."""
    if name=='screenplay':
        data={'project':{k:v for k,v in c['project'].items() if k!='mode'},
              'screenplay':c['screenplay'],'shots':c['shots'],'instances':c['instances'],
              'events':[{k:v for k,v in e.items() if k!='audio'} for e in c['events']],
              'assets':{k:a['type'] for k,a in c['assets'].items()},
              'actions':{k:a['owner'] for k,a in c['actions'].items()}}
    elif name=='graybox': data={'graybox':c['graybox']}
    elif name=='assets': data={'assets':c['assets'],'mode':c['project']['mode']}
    elif name=='prepare': data={'actions':c['actions']}
    elif name=='render': data={'audio':c['audio'],'event_audio':{e['id']:e.get('audio') for e in c['events']}}
    else: data={}
    return {'contract':data,'hook':c['stages'].get(name)}

def stage_files(c,name):
    if name=='screenplay': return [c['screenplay']]
    if name=='assets': return [a['image'] for a in c['assets'].values()]
    if name=='prepare': return [p for a in c['actions'].values() for p in a['paths']]
    if name=='render': return [q['path'] for q in c['audio']['cues']]
    return []

def fingerprint(config,c,name):
    root=Path(config).parent
    # Missing planned resources are stable values, never a readiness bypass.
    files={p:sha(local(root,p)) if local(root,p,False).is_file() else None for p in stage_files(c,name)}
    return {'definition':stage_contract(c,name),'files':files}

def invalidate(state,index):
    for name in STAGES[index:]:
        state['approvals'].pop(name,None)
        if name in state['stages']: state['stages'][name]['status']='STALE'

def revalidate_upstream_outputs(config,c,state,current_index):
    """A hook may touch shared artifacts beyond its declared inputs/outputs."""
    root=Path(config).parent
    for index,name in enumerate(STAGES[:current_index]):
        record=state['stages'].get(name)
        if not record or record.get('status')!='PASS': continue
        try: changed=hashes(root,list(record['outputs']))!=record['outputs']
        except (ValueError,OSError): changed=True
        if changed:
            invalidate(state,index)
            raise ValueError(f'approved upstream output changed during hook: {name}; review invalidated')
        try:
            changed=(hashes(root,list(record['inputs']))!=record['inputs'] or
                     fingerprint(config,c,name)!=record['fingerprint'])
        except (ValueError,OSError): changed=True
        if changed:
            invalidate(state,index)
            raise ValueError(f'approved upstream inputs changed during hook: {name}; review invalidated')

def status(config):
    config=Path(config).resolve(); path=state_path(config)
    state=json.loads(path.read_text()) if path.exists() else {'stages':{},'approvals':{}}
    try:
        c=load(config,'plan')
        first=len(STAGES)
        for i,name in enumerate(STAGES):
            record=state['stages'].get(name)
            if record and record.get('status')!='PASS': first=min(first,i+1)
            if record and record.get('status')=='PASS':
                try:
                    if record.get('fingerprint')!=fingerprint(config,c,name) or hashes(config.parent,list(record['inputs']))!=record['inputs'] or hashes(config.parent,list(record['outputs']))!=record['outputs']: first=min(first,i)
                except (ValueError,OSError): first=min(first,i)
        invalidate(state,first)
        state.pop('fingerprint',None); state.pop('error',None)
    except (ValueError,OSError) as e:
        for record in state['stages'].values(): record['status']='STALE'
        state['approvals']={}; state['error']=str(e)
        write_state(config,state)
        raise
    write_state(config,state); return state

def approve(config,gate,actor,note):
    if actor not in ('user','executor') or not note.strip(): raise ValueError('approval requires identified actor and a review note')
    c=load(config,'plan'); policy=c['project'].get('review_policy',{})
    if actor=='executor' and not policy.get('executor_review_authorized',False): raise ValueError('executor review requires explicit project authorization')
    state=status(config)
    if gate not in STAGES or state['stages'].get(gate,{}).get('status')!='PASS': raise ValueError('gate needs a successful current execution report')
    if state['stages'][gate].get('diagnostic'): raise ValueError('diagnostic bypass execution cannot receive production approval')
    state['approvals'][gate]={'actor':actor,'note':note,'fingerprint':state['stages'][gate]['fingerprint'],'outputs':state['stages'][gate]['outputs']}
    if actor=='executor': state['approvals'][gate]['authorization_note']=policy['authorization_note']
    write_state(config,state); return state

def run(config,through=None,diagnostic=False):
    config=Path(config).resolve(); c=load(config,'plan'); state=status(config)
    through=through or STAGES[-1]
    if through not in STAGES: raise ValueError('unknown stage')
    if diagnostic and not c['project']['test_only']: raise ValueError('diagnostic bypass is limited to TEST_ONLY projects')
    gates=c['project'].get('review_policy',{}).get('human_gates',HUMAN_GATES)
    for i,name in enumerate(STAGES[:STAGES.index(through)+1]):
        previous=STAGES[i-1] if i else None
        skipped_graybox=previous=='graybox' and not c['graybox']['required']
        if previous in gates and not skipped_graybox and not diagnostic and previous not in state['approvals']: raise ValueError(f'authorized review required: {previous}')
        if name=='release' and (diagnostic or c['project']['test_only'] or c['project']['mode']!='formal' or any(a['status']!='formal' for a in c['assets'].values())): raise ValueError('production release forbids diagnostic/test/graybox assets')
        record=state['stages'].get(name,{})
        if record.get('status')=='PASS' and record.get('diagnostic')==diagnostic: continue
        if name=='graybox' and not c['graybox']['required']:
            state['stages'][name]={'status':'PASS','decision':'not_required','reason':c['graybox']['reason'],'executor':'local-contract','inputs':{},'outputs':{},'diagnostic':diagnostic,'fingerprint':fingerprint(config,c,name)}
            write_state(config,state)
            continue
        try:
            stage_ready(c,config.parent,name)
            spec=c['stages'].get(name)
            if not spec: raise ValueError(f'missing stage configuration: {name}')
            command=spec.get('command')
            if not isinstance(command,list) or not command or any(not isinstance(x,str) or not x for x in command): raise ValueError(f'missing stage command array: {name}')
            if not spec.get('inputs') or not spec.get('outputs'): raise ValueError(f'stage inputs and outputs required: {name}')
            if name in ('review','release') and not spec.get('report'): raise ValueError(f'stage requires structured report: {name}')
            if spec.get('report') and spec['report'] not in spec['outputs']: raise ValueError('stage report must be a declared output')
            before=hashes(config.parent,spec['inputs'])
            consumed=hashes(config.parent,stage_files(c,name)) if name in ('screenplay','render') else {}
            definition=stage_contract(c,name)
            if name=='graybox':
                definition=json.loads(json.dumps(definition))
                definition['contract']['graybox'].pop('result')
            timeout=integer(spec.get('timeout',300),'stage timeout',1)
            try:
                result=subprocess.run(command,cwd=config.parent,shell=False,capture_output=True,text=True,timeout=timeout)
            finally:
                revalidate_upstream_outputs(config,c,state,i)
            if result.returncode: raise ValueError(f'stage {name} subprocess failed ({result.returncode}): {result.stderr[-2000:]}')
            try: outputs=hashes(config.parent,spec['outputs'])
            except ValueError as e: raise ValueError(f'stage output missing: {e}') from e
            if spec.get('report'):
                external=json.loads(local(config.parent,spec['report']).read_text(encoding='utf-8'))
                if not isinstance(external,dict) or external.get('status')!='PASS': raise ValueError(f'stage report failed or uncertain: {name}')
            if before!=hashes(config.parent,spec['inputs']): raise ValueError('stage changed its declared inputs')
            if consumed!=hashes(config.parent,list(consumed)): raise ValueError('stage scene inputs changed during execution')
            updated=load(config,'plan')
            for j,upstream in enumerate(STAGES[:i]):
                if fingerprint(config,updated,upstream)!=state['stages'][upstream]['fingerprint']:
                    invalidate(state,j)
                    raise ValueError(f'upstream scene inputs changed during stage: {upstream}; review invalidated')
            current_definition=stage_contract(updated,name)
            if name=='graybox':
                current_definition=json.loads(json.dumps(current_definition))
                current_definition['contract']['graybox'].pop('result')
            if definition!=current_definition: raise ValueError('stage contract changed during execution')
            stage_ready(updated,config.parent,name,completed=True)
            c=updated
            state['stages'][name]={'status':'PASS','executor':'local-subprocess','inputs':before,'outputs':outputs,'diagnostic':diagnostic,'stdout':result.stdout[-2000:],'fingerprint':fingerprint(config,c,name)}
            if name not in gates: state['stages'][name]['technical_review']={'actor':'executor','note':'Process succeeded and declared output hashes verified','outputs':outputs}
            state['approvals'].pop(name,None)
        except (ValueError,OSError,subprocess.SubprocessError) as e:
            state['stages'][name]={'status':'FAIL','error':str(e)}
            for downstream in STAGES[i:]:
                state['approvals'].pop(downstream,None)
                if downstream!=name and downstream in state['stages']: state['stages'][downstream]['status']='STALE'
            write_state(config,state)
            raise ValueError(str(e)) from e
        write_state(config,state)
    return state

def init(workspace,name,duration,fps,resolution):
    root=Path(workspace).resolve(); root.mkdir(parents=True,exist_ok=True); path=root/'2d-pipeline.json'
    if path.exists(): raise ValueError('config already exists')
    integer(duration,'duration',1); integer(fps,'fps',1)
    w,h=map(int,resolution.lower().split('x'))
    if w<2 or h<2 or w%2 or h%2: raise ValueError('resolution must be positive even dimensions')
    c={'schema_version':1,'project':{'name':name,'fps':fps,'frame_count':duration*fps,'resolution':[w,h],'mode':'formal','test_only':False},'screenplay':'screenplay.md','graybox':{'required':True,'reason':'Decision required before production','result':'pending'},'shots':[],'assets':{},'actions':{},'instances':[],'events':[],'audio':{'silence':False,'cues':[]},'stages':{n:{'command':[],'inputs':[],'outputs':[],'review':True} for n in STAGES}}
    path.write_text(json.dumps(c,indent=2),encoding='utf-8'); return path

def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('init'); q.add_argument('--workspace',required=True); q.add_argument('--name',required=True); q.add_argument('--duration',type=int,default=15); q.add_argument('--fps',type=int,default=30); q.add_argument('--resolution',default='1080x1920')
    for cmd in ('status','run','approve'):
        q=sub.add_parser(cmd); q.add_argument('--config',type=Path,required=True)
        if cmd=='run': q.add_argument('--through',choices=STAGES); q.add_argument('--diagnostic',action='store_true')
        if cmd=='approve': q.add_argument('--gate',choices=STAGES,required=True); q.add_argument('--actor',choices=['user','executor'],required=True); q.add_argument('--note',required=True)
    a=p.parse_args()
    try:
        if a.cmd=='init': result=init(a.workspace,a.name,a.duration,a.fps,a.resolution)
        elif a.cmd=='run': result=run(a.config,a.through,a.diagnostic)
        elif a.cmd=='approve': result=approve(a.config,a.gate,a.actor,a.note)
        else: result=status(a.config)
        print(json.dumps(result,indent=2,default=str))
    except (ValueError,OSError,KeyError) as e: p.exit(1,f'FAIL: {e}\n')

if __name__=='__main__': main()
