# 当前命令与 schema v1

以仓库当前脚本 `--help` 和 `scripts/fixture.py` 为准；升级脚本后重新核对本文，不凭记忆补参数。

## 初学者启动

用户可以直接说：

> 使用 $2d-pipeline，做一支 15 秒竖屏原创短片：送货员把包裹送到被升降杆阻挡的取件站，发现按钮、按下后杆升起，最终成功交付。明亮扁平 2D 风格。请你负责完整剧本、分镜、全部素材清单、按需灰盒、每个动作的姿势序列、Godot 编排、声音和 MP4；先给我审需要确认的内容，未经同意不要付费生成或发布。

这只是可运行的请求示例，不是固定题材或结构。

## CLI

```text
python scripts/pipeline.py init --workspace PATH --name NAME --duration 15 --fps 30 --resolution 1080x1920
python scripts/pipeline.py status --config PATH
python scripts/pipeline.py run --config PATH [--through STAGE] [--diagnostic]
python scripts/pipeline.py approve --config PATH --gate STAGE --actor user --note TEXT
python scripts/fixture.py --workspace NEW_PATH
python scripts/prepare.py --spec SPEC_JSON
python scripts/build.py --config CONFIG_JSON
python scripts/render.py --config CONFIG_JSON [--godot PATH] [--ffmpeg PATH] [--ffprobe PATH] [--diagnostic] [--timeout SECONDS]
```

先使用 `python --version`（Windows 也可用 `py -3 --version`）发现可用解释器；后续命令中的 `python` 代表这个已验证解释器。缺少 Pillow 时，在 Skill 根目录运行实际依赖安装命令 `python -m pip install -r requirements.txt`。Godot、FFmpeg 和 ffprobe 也必须先发现真实可执行文件。

PowerShell 开发者诊断示例（工具路径必须替换为本机已发现的真实路径）：

```powershell
python -X utf8 scripts/fixture.py --workspace scratch/diagnostic
python -X utf8 scripts/render.py --config scratch/diagnostic/2d-pipeline.json --godot C:/path/to/Godot_console.exe --ffmpeg C:/path/to/ffmpeg.exe --ffprobe C:/path/to/ffprobe.exe --diagnostic --timeout 180
```

`fixture.py` 生成 TEST_ONLY 合成诊断资产。`--diagnostic` 仅能跳过 TEST_ONLY 项目的人工门，不能发布。`init` 故意生成不完整生产合同；Codex 先补齐真实剧本及完整的分镜、事件、资产/动作/声音计划。`status` 校验这些规划结构，允许下游路径尚无文件和灰盒结果为 `pending`；成功只表示状态可读取，不表示全部素材就绪。阶段 `command` 是字符串数组，由 Codex 在发现实际本地工具后配置；不支持 shell 展开，不可用空命令或占位输出伪造通过。

## 顶层 schema

所有路径相对配置所在工作区且不可越界。所有对象拒绝未知字段。

- `schema_version`: 固定整数 `1`。
- `project`: `name`、正整数 `fps`/`frame_count`、`resolution: [even_width,even_height]`、`mode` (`formal|graybox`)、`test_only`，可选 `review_policy`。
- `screenplay`: 非空 Markdown 相对路径；长度检查只防缺失，不证明故事质量。
- `graybox`: `required`、非空 `reason`、`result` (`pending|pass|not_required`)。
- `shots`: 连续覆盖全片的 `{id,start,end,state_in,state_out,camera}`；`camera` 只有 `position_keys` 和正值 `zoom_keys`。
- `assets`: ID 映射到 `{type,image,source,status,require_alpha}`。type 仅 `character|scenery|prop|effect`；status 仅 `formal|graybox|test`。
- `actions`: ID 映射到 `{owner,paths,holds,expected_count,loop}`。paths 顺序即姿势顺序；paths/holds 长度严格等于 expected_count；holds 是正整数帧。
- `instances`: 数组项 `{id,asset,action?,start,end,position_keys,scale_keys,rotation_keys,z}`。
- `events`: 数组项 `{id,actor,target,start,end,cause,response,result,audio?}`；事件期间双方必须可见。
- `audio`: `{silence,cues}`；cue 为 `{id?,path,start,duration,volume}`，时间均为帧。静音时 cues 为空；非静音必须有 cue。
- `stages`: 阶段映射到 `{command,inputs,outputs,review?,timeout?,report?}`。

时间区间均为零基、结束不包含的 `[start,end)`。位置/缩放是二维 key，旋转是角度标量；key 为 `{frame,value}` 并按绝对项目帧严格递增。缩放/相机 zoom 必须为正；z 是 Godot `[-4096,4096]` 内整数。同 z 按 manifest 顺序。非循环 action 达到 holds 总和后在实例仍可见时保持末姿势；循环 action 用总 holds 取模。

## 姿势准备合同

```json
{
  "source": "art/pose-sheet.png",
  "output": "prepared/walk",
  "expected_count": 6,
  "canvas": [512, 512],
  "offset": [96, 64],
  "scale": 1.0,
  "require_alpha": true,
  "crops": [
    [0, 0, 256, 256],
    [256, 0, 512, 256],
    [512, 0, 768, 256],
    [0, 256, 256, 512],
    [256, 256, 512, 512],
    [512, 256, 768, 512]
  ]
}
```

上例表示一张 768×512 的 3×2 姿势表；六个 crop 与 `expected_count: 6` 一致。所有 crop 使用同一 scale 和明确 offset；输出目录必须尚不存在。输出含有序 `manifest.json` 与 `contact-sheet-TECHNICAL-ONLY.png`。独立 PNG 不经过自动拟合：先确认尺寸、alpha、主体比例与共同局部锚点，再按明确顺序直接填 action.paths。

## 阶段与授权

固定阶段：`screenplay, graybox, assets, prepare, storyboard, build, render, review, release`。默认人工门：`screenplay, graybox, assets, storyboard, review, release`。不需要灰盒时流水线记录 `not_required`，不会调用假钩子。

这里的 runner 名称不等于创作顺序：剧情分镜与事件设计必须在资产清单和生图之前完成。runner 中位于 `prepare` 后的 `storyboard` 是“整理后的动作预览与全片分镜实现审查门”，用于核对正式帧、动作和既定分镜，不是第一次写分镜。

每阶段执行前验证已消费资源，执行后验证该阶段产物：

| 阶段 | 就绪与产物要求 | 所属合同及文件变化从何处失效 |
|---|---|---|
| screenplay | 真实剧本和完整规划；未来图片/姿势/声音路径可尚不存在 | 项目时长/画幅/审批策略、剧本、镜头、对象、因果事件、资产类型与动作归属从本阶段失效 |
| graybox | 必要时执行真实预演钩子，完成后必须 `result:pass`；不需要则记录跳过理由 | 灰盒判断、结果或预演证据从本阶段失效 |
| assets | 必要灰盒已通过；钩子完成后所有资产图片、alpha、正式状态合格 | 资产路径、来源、状态、图片字节及模式从本阶段失效 |
| prepare | 输入资产合格；完成后每张有序姿势都存在且 alpha/画布合格 | 动作路径、holds、数量、循环及姿势字节从本阶段失效 |
| storyboard / build | 完整图片与姿势已合格 | 各自钩子及声明输入/输出变化从各自阶段失效 |
| render / review / release | 完整资源（包括声音文件）已就绪；保留报告、审批和正式发布限制 | 声音合同、事件配声、音频字节从 render 失效 |

每阶段还绑定自己的 `command/inputs/outputs/report/timeout`；命令引用的脚本、准备 spec 等也应列入 `inputs`，以检测其内容变化。依赖沿固定阶段顺序向后传播：所属阶段或任一上游输入/输出变化，会撤销该阶段及其后续审批，保留无关的早期审批。旧版全局指纹记录首次读取会失效，需重新执行和审查。

钩子可以创建当前阶段声明的产物，并更新尚未执行的下游计划；当前合同不能在执行中被改写，唯独灰盒钩子可把其结果更新为 `pass`。上游合同、已批准输出或已消费输入被改写时立即失败并撤销相应审批。所有声明的 `inputs` 执行前必须真实存在；未来文件不能冒充当前输入。单独的 `contract.load`、`build.py`、`render.py` 仍执行完整资源校验；直接构建/渲染前需补齐完整合同。

`project.review_policy` 的精确字段：

```json
{
  "human_gates": ["screenplay", "assets", "storyboard", "review", "release"],
  "executor_review_authorized": true,
  "authorization_note": "用户明确授权本项目由执行器按证据审查这些门"
}
```

只有该显式授权存在时才可 `approve --actor executor`，且每次仍需真实 review note。它只委托项目审查，不扩大费用、模型、重试、登录、上传或发布权限。`actor:user` 表示实际用户审过，执行器不可自行声称。review/release 必须有 declared output JSON report 且 `status` 为 `PASS`；报告成功也不能替代感知验收。
